package edu.sharif.oop;

import java.util.Arrays;
import java.util.Iterator;

public class CrudOperation <E> {

        private E[] data;
        // This Constructor is Generic
        public CrudOperation(E[] data) {
            this.data = data;
        }

        /*
         * This method is for READ or GET element of Array
          */
        public  E read (int index) {
            E test =  data[index];
            return test ;
        }

        /*
         * This method is for CREATE or INSERT element in Array
         * */
        public void insert(E element) {
            E[] result;
            result= Arrays.copyOf(data,data.length+1);
            result[data.length]=element;
            data=result;
        }

        /*
         * This method is for INSERT element in Array but with index
         * */
        public void insert(E element , int index) {
            E[] result = null;
            result= Arrays.copyOf(data,data.length+1);
            System.arraycopy(data,0,result,0,index);
            result[index]=element;
            System.arraycopy(data,index,result,index+1,data.length-index);
            data=result;
        }

        /*
         * Update Your Array with set two params first param is index of element
         * that you want update this element and second param is new element
         * */
        public E[] update(int index , E newElement) {
            data[index]=newElement;
            return data;
        }

        /*
         * Delete Element of Array with Index
         * */
        public void delete(int index) {
            E[] result = null;
            result= Arrays.copyOf(data,data.length-1);
            if(index>0){
                System.arraycopy(data,0,result,0,index);
            }
            if(index<data.length-1){
                System.arraycopy(data,index+1,result,index,data.length-index-1);
            }
            data=result;
        }

        /*
         * Delete Element of Array with element
         * */
        public void delete1(E element) {
            int counter=0;
            E[] result = null;counter=0;
            for (E e : data) {
                if(e.equals(element)){
                    counter++;
                }
            }
            result= Arrays.copyOf(data,data.length-counter);
            int index_start=0,null_numbers=0;counter=0;
            for (int i = 0; i < data.length; i++) {
                if(data[i].equals(element) || i==data.length-1){
                    if( i==data.length-1 && !data[i].equals(element)){
                        System.arraycopy(data,index_start,result,index_start-null_numbers,counter+1);
                        null_numbers++;
                        index_start=i+1;counter=0;
                    }else {
                        System.arraycopy(data,index_start,result,index_start-null_numbers,counter);
                        null_numbers++;
                        index_start=i+1;counter=0;
                    }
                }else {
                    counter++;
                }
            }
            data=result;
        }

        /*
         * Eliminate inappropriate pairs method
         * */



        public E[] getData() {
            return data;
        }


    }


