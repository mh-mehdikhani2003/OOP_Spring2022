import edu.sharif.oop.CrudOperation;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

public class part_two {
    public Integer[] eliminateInappropriatePairs(Integer[] arr,CrudOperation <Integer> integerCrudOperation) {
        if(arr.length%2==1){
            integerCrudOperation.delete(arr.length-1);
            for (int i = 0; i < arr.length; i+=2) {
                if(arr[i]>arr[i+1]){
                    integerCrudOperation.delete(i);
                    integerCrudOperation.delete(i);
                    i-=2;
                    arr=  integerCrudOperation.getData();
                }
            }
        }else {
            for (int i = 0; i < arr.length; i+=2) {
                if(arr[i]>arr[i+1]){
                    integerCrudOperation.delete(i);
                    integerCrudOperation.delete(i);
                    i-=2;
                    arr=integerCrudOperation.getData();
                }
            }
        }
        return arr;
    }
    public void start(Scanner scanner){
        ArrayList<Integer> integerArrayList=new ArrayList<>();
        System.out.println("input elements:(or type end to stop)");
        String input= scanner.next();
        while (!input.equals("end")){
            integerArrayList.add(Integer.parseInt(input));
            System.out.println("input elements:(or type end to stop)");
            input= scanner.next();
        }
        CrudOperation<Integer> integerCrudOperation=new CrudOperation<Integer>(integerArrayList.toArray(new Integer[0]));
        Integer[] arr = new Integer[integerArrayList.size()];
        integerArrayList.toArray(arr);
        arr=eliminateInappropriatePairs(arr,integerCrudOperation);
        System.out.println(Arrays.toString(arr));
    }

}
