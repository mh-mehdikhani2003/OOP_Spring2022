import edu.sharif.oop.CrudOperation;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

public class MAINCLASS {
    public static void CREATE(Scanner scanner,int index,CrudOperation crudOperation){
        System.out.println("Do you wish to add element to an special index or not?");
        System.out.println("1.YES");
        System.out.println("2.NO");
        int messege=scanner.nextInt();
        String payam="";
        if(messege==1){
            System.out.println("Please enter your index :(or type back)");
            payam= scanner.next();
            if(payam.equals("back")){
                menu(scanner,index,crudOperation);
            }else {
                while (Integer.parseInt(payam)<0 || Integer.parseInt(payam)>=index){
                    System.out.println("enter a valid index:");
                    payam=scanner.next();
                }
            }
            System.out.println("Please enter your element:(INTEGER)");
            messege=scanner.nextInt();
            crudOperation.insert(messege,Integer.parseInt(payam));
        }else if(messege==2){
            System.out.println("please  enter your element:(INTEGER)(or type back for menu)");
            payam= scanner.next();
            if(payam.equals("back")){
                menu(scanner,index,crudOperation);
            }else {
                crudOperation.insert(Integer.parseInt(payam));
            }
        }
    }
    public static Integer READ(Scanner scanner,CrudOperation <Integer>crudOperation,int index){
        System.out.println("Please enter your index:(type back for menu)");
        String index1 =scanner.next();
        if(index1.equals("back")){
            menu(scanner,index,crudOperation);
            return null;
        }else {
            while (Integer.parseInt(index1)<0 || Integer.parseInt(index1)>=index){
                System.out.println("enter valid index");index1 =scanner.next();
            }
            return crudOperation.read(Integer.parseInt(index1));
        }
    }
    public static Integer[] UPDATE(Scanner scanner,CrudOperation <Integer>crudOperation,int index){
        System.out.println("Please enter your index:(type back for menu)");
        String payam=scanner.next();
        if(payam.equals("back")){
            menu(scanner,index,crudOperation);
            return null;
        }else {
            while (Integer.parseInt(payam)<0 || Integer.parseInt(payam)>=index){
                System.out.println("please enter valid index");
                payam=scanner.next();
            }
            System.out.println("please enter the element:(INTEGER)");
            Integer element= scanner.nextInt();
            return crudOperation.update(Integer.parseInt(payam),element);
        }
    }
    public static void DELETE(Scanner scanner,CrudOperation<Integer> crudOperation,int index){
        System.out.println("Do you you wish to delete by index or element:");
        System.out.println("1.element");
        System.out.println("2.index");
        System.out.println("3.back");
        String messege= scanner.next();
        if(messege.equals("1")){
            System.out.println("please enter the element :(INTEGER)");
            messege= scanner.next();
            crudOperation.delete1(Integer.parseInt(messege));
        }else if(messege.equals("2")){
            System.out.println("please enter the index :(or type back for menu)");
            messege= scanner.next();
            if(messege.equals("back")){
                menu(scanner,index,crudOperation);
            }else {
                while (Integer.parseInt(messege)<0 || Integer.parseInt(messege)>=index){
                    System.out.println("enter valid index:");
                    messege= scanner.next();
                }
                crudOperation.delete(Integer.parseInt(messege));
            }
        }else if(messege.equals("3")){
            menu(scanner,index,crudOperation);
        }
    }
    public static void menu(Scanner scanner,int index,CrudOperation crudOperation){
        int messege=0;
        System.out.println("1.CREATE");
        System.out.println("2.READ");
        System.out.println("3.UPDATE");
        System.out.println("4.DELETE");
        System.out.println("5.EXIT");
        messege=scanner.nextInt();
        if(messege==1){
            CREATE(scanner,index,crudOperation);
        }else if(messege==2){
           Integer nigga = READ(scanner,crudOperation,index);
            System.out.println("answer:");
            System.out.println(nigga);
        }else if(messege==3){
            Integer[] niggatoo =UPDATE(scanner,crudOperation,index);
            System.out.println("answer:");
            System.out.println(Arrays.toString(niggatoo));
        }else if(messege==4){
            DELETE(scanner,crudOperation,index);
        }else if(messege==5){
            return;
        }
    }

    public static void  main(String[] args) {
        int index=0;
        Scanner scanner =new Scanner(System.in);
        System.out.println("Do you want to do the second part or first part?");
        System.out.println("1.first part");
        System.out.println("2.second part");
        index= scanner.nextInt();
        if(index==2){
            part_two part_two =new part_two();
            part_two.start(scanner);
        }else {
            System.out.println("please enter index:");
            index= scanner.nextInt();
            Integer [] test = new Integer[index];
            System.out.println("please enter elements:(Integer)");
            for (int i = 0; i < test.length; i++) {
                test[i]= scanner.nextInt();
            }
            CrudOperation<Integer> crudOperation= new CrudOperation<>(test);
            menu(scanner,index,crudOperation);
            System.out.println(Arrays.toString(crudOperation.getData()));
        }
    }
}
