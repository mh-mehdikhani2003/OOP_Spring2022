package input;

import jdbc.Database;
import repository.PostRepository;

import java.sql.SQLException;
import java.util.Scanner;

public class CreatePostMenu {
    public static final int MENU_NUM = 6;
    private static final Scanner scanner = new Scanner(System.in);
    public static void input_processor(String input) {
        // help
        if (input.equalsIgnoreCase("help"))
            System.out.println("""
                    POST MENU:
                    * ADD TEXT
                    * ADD LOCATION
                    help
                    return
                    exit
                    """
            );

        // exit
        else if (input.equalsIgnoreCase("exit")){
            MenuControl.setRun(false);
        }

        // return
        else if (input.equalsIgnoreCase("return")){
            MenuControl.setMenuNum(MainMenu.MENU_NUM);
        }

        // ad text
        else if (input.equalsIgnoreCase("add text")) {
            try {
                PostRepository.create_post();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        // add location
        else if (input.equalsIgnoreCase("add location")) {
            System.out.println("please enter the postID:");
            String postId = scanner.nextLine().trim();
            try {
                while (!Database.check_existence_post(postId)){
                    System.out.println(postId+" doesn't exist.enter again :");
                    postId = scanner.nextLine().trim();
                }
                    PostRepository.Update_Location(postId);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
