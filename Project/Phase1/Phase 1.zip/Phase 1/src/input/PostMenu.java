package input;

public class PostMenu {
    public void input_processor(String input) {
        // help
        if (input.equalsIgnoreCase("help"))
            System.out.println("post");
    }
}
