package repository;

import entity.Like;
import input.HomePage;
import input.MenuControl;
import jdbc.Database;

import java.sql.SQLException;
import java.util.Scanner;

public class LikesRepository {
    private static final Scanner scanner = new Scanner(System.in);

    public static void create_likes () throws SQLException {
        String post_comment_id = Like_OR_post_ID();
        if(post_comment_id.isEmpty()){
            MenuControl.setMenuNum(HomePage.MENU_NUM);
            MenuControl.inputScanner();
        }
        String LikerID = liker_ID(post_comment_id);
        if(LikerID.isEmpty()){
            MenuControl.setMenuNum(HomePage.MENU_NUM);
            MenuControl.inputScanner();
        }
        int a;
        if(post_comment_id.charAt(post_comment_id.length()-1)=='#'){
            a = Database.get_likesNum_from_comments(post_comment_id.substring(0,post_comment_id.length()-1))+1;
            Database.Update_likesNum_into_comments(a,post_comment_id.substring(0,post_comment_id.length()-1));
        }else if(post_comment_id.charAt(post_comment_id.length()-1)=='*'){
            a = Database.get_likesNum_from_posts(post_comment_id.substring(0,post_comment_id.length()-1))+1;
                Database.Update_likesNum_into_posts(a,post_comment_id.substring(0,post_comment_id.length()-1));
        }

        String LikeID = Like_ID(post_comment_id,LikerID);


        if (Database.add_likes(new Like(post_comment_id,LikeID,LikerID)) > 0){
            System.out.println("Liked successful.");
        }else System.err.println("Something went wrong!\n try again.");
    }

    public static void Delete_Like (){
        System.out.println("please enter like id :");
        while (true){
            try{
                String cap= scanner.nextLine().trim();
                if(cap.isEmpty()){
                    System.out.println("Don't enter empty String. dude?!");
                }else {
                    if(Database.delete_like(cap)){
                        int index =0;
                        for (int i = cap.length()-1 ; i >= 0 ; i--) {
                            if(cap.charAt(i)=='*' || cap.charAt(i)=='#' ){
                                index= i;break;
                            }
                        }
                        int a;
                        String post_comment_id = cap.substring(0,index+1);
                        if(post_comment_id.charAt(post_comment_id.length()-1)=='#'){
                            a = Database.get_likesNum_from_comments(post_comment_id.substring(0,post_comment_id.length()-1))-1;
                            Database.Update_likesNum_into_comments(a,post_comment_id.substring(0,post_comment_id.length()-1));
                        }else if(post_comment_id.charAt(post_comment_id.length()-1)=='*'){
                            a = Database.get_likesNum_from_posts(post_comment_id.substring(0,post_comment_id.length()-1))-1;
                            Database.Update_likesNum_into_posts(a,post_comment_id.substring(0,post_comment_id.length()-1));
                        }
                        System.out.println("Like deleted.");return;
                    }else {
                        System.out.println("wrong id");
                    }
                }
            }catch (Exception e){
                e.printStackTrace();
                //System.out.println("invalid command!");
            }
        }
    }

    public static String Like_OR_post_ID (){
        System.out.println("Please enter the id of the post or comment:");
        while (true){
            try {
                String input= scanner.nextLine().trim();
                if(input.isEmpty()){
                    System.err.println("id can't be empty.");
                }else {
                    System.out.println("Is it a commentID or a post ID?(comment/post)");
                   String caption= scanner.nextLine().trim();
                    if(caption.equalsIgnoreCase("comment")){
                        if(Database.check_existence_comment(input)){
                            return input+"#";
                        }else {
                            System.out.println("There is no comment with such ID!");
                            return "";
                        }
                    }else if (caption.equalsIgnoreCase("post")){
                        if(Database.check_existence_post(input)){
                            return input+"*";
                        }else {
                            System.out.println("There is no post with such ID!");
                            return "";
                        }
                    }
                }
            }catch (Exception e){
                System.err.println("invalid command.");
            }
        }
    }

    public static String liker_ID(String post_commentID) throws SQLException{
        String user_loggedin =Database.user_loggedIn();
        while (true){
            try {
                if(user_loggedin.isEmpty()){
                    System.out.println("No body is loggedIn!");
                }else {
                    if(Database.CheckForDuplicateLike(post_commentID,user_loggedin)){
                        System.out.println("Already liked by you.");
                        return "";
                    }else {
                        return user_loggedin;
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public static String Like_ID(String post_comment_id_like,String LikerID) throws SQLException {
        String Liker= LikerID;
        String post_comment_ID = post_comment_id_like ;
        return post_comment_ID+Liker;
    }
}
