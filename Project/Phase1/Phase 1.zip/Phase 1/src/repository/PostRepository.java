package repository;

import entity.Post;
import entity.Time;
import input.MainMenu;
import jdbc.Database;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;

public class PostRepository {
    private static final Scanner scanner = new Scanner(System.in);
    private static String userID;

    public static void setUserID(String userID) {
        PostRepository.userID = userID;
    }

    public static void create_post () throws SQLException {
        String caption = post_addText();
        String posterID = post_posterID();
        String postID = post_postID();

        boolean ad=post_ad();
        String picture=post_picture();
        String time=post_time();
        String field = post_field();

        System.out.println("Type POST to send the post. ");
        String sure = scanner.nextLine().trim();
        while (!sure.equalsIgnoreCase("POST")) {
            System.out.println("Please type POST!");
            sure = scanner.nextLine().trim();
        }

        if (Database.add_post(new Post( postID, posterID, ad,
                picture,caption,time,field)) > 0){
            System.out.println("Posted the post successfully.");
        }else System.err.println("Something went wrong!\n try again.");
    }

    //there is three ways for scoring for an AD post:
    //having more LikesNum and ViewsNum.
    //having the most liked field by the user(the similarity wanted between posts)
    //having been liked by user's followers and followings (because the following and followers probably will have the same taste in fields of a post as the taste of the user)
    public static void ADVERTISING_posts () throws SQLException {
        String UserID = MainMenu.getUserID();
        ResultSet resultSetLikes = Database.getLikes();
        ArrayList <String> postIDs_likedByUSer = new ArrayList<>();
        while (resultSetLikes.next()){
            if(resultSetLikes.getString(1).contains("*") && !resultSetLikes.getString(1).contains("#") && resultSetLikes.getString("Liker_ID").equals(userID)){
                postIDs_likedByUSer.add(resultSetLikes.getString(1).substring(0,resultSetLikes.getString(1).length()-1));
            }
        }
        //giving scores based on popularity in userLiked AD-posts
        int [] fields_likes = new int[9];
        ResultSet resultSet_AD_posts = Database.get_ADposts();
        //considering ids and scores for ADposts
        ArrayList <String> ids_AD_posts = new ArrayList<>();
        ArrayList <Double> Scores = new ArrayList<>();

        while (resultSet_AD_posts.next()){
            //The first way of scoring : (next two lines)
            ids_AD_posts.add(resultSet_AD_posts.getString("id"));
            Scores.add(Double.parseDouble(resultSet_AD_posts.getString("likesNum"))/10+Double.parseDouble(resultSet_AD_posts.getString("viewsNum"))/100);
            //                1.sports
            //                2.entertainment
            //                3.nature
            //                4.educational
            //                5.fashion
            //                6.political
            //                7.music
            //                8.movie
            //                9.economics

            for (String postID_liked : postIDs_likedByUSer) {
                //checking for being AD between posts that are liked by user
                if(postID_liked.equals(resultSet_AD_posts.getString("id"))){

                    switch (resultSet_AD_posts.getString("field")){
                        case "1.sports": fields_likes[0]+=1;break;
                        case "2.entertainment": fields_likes[1]+=1;break;
                        case "3.nature": fields_likes[2]+=1;break;
                        case "4.educational": fields_likes[3]+=1;break;
                        case "5.fashion": fields_likes[4]+=1;break;
                        case "6.political": fields_likes[5]+=1;break;
                        case "7.music": fields_likes[6]+=1;break;
                        case "8.movie": fields_likes[7]+=1;break;
                        case "9.economics": fields_likes[8]+=1;break;
                    }

                }
            }
        }
        //second way of scoring :
        resultSet_AD_posts.beforeFirst();
        int counter=0;
        while (resultSet_AD_posts.next()){
                switch (resultSet_AD_posts.getString("field")){
                    case "1.sports": Scores.set(counter,Scores.get(counter)+(double)10*fields_likes[0]/postIDs_likedByUSer.size());break;
                    case "2.entertainment": Scores.set(counter,Scores.get(counter)+(double)10*fields_likes[1]/postIDs_likedByUSer.size());break;
                    case "3.nature": Scores.set(counter,Scores.get(counter)+(double)10*fields_likes[2]/postIDs_likedByUSer.size());break;
                    case "4.educational": Scores.set(counter,Scores.get(counter)+(double)10*fields_likes[3]/postIDs_likedByUSer.size());break;
                    case "5.fashion": Scores.set(counter,Scores.get(counter)+(double)10*fields_likes[4]/postIDs_likedByUSer.size());break;
                    case "6.political": Scores.set(counter,Scores.get(counter)+(double)10*fields_likes[5]/postIDs_likedByUSer.size());break;
                    case "7.music": Scores.set(counter,Scores.get(counter)+(double)10*fields_likes[6]/postIDs_likedByUSer.size());break;
                    case "8.movie": Scores.set(counter,Scores.get(counter)+(double)10*fields_likes[7]/postIDs_likedByUSer.size());break;
                    case "9.economics": Scores.set(counter,Scores.get(counter)+(double)10*fields_likes[8]/postIDs_likedByUSer.size());break;
                }
                counter++;
        }



        resultSet_AD_posts.beforeFirst();
        ResultSet Followers = Database.get_followersTable(userID);
        ResultSet Followings = Database.get_followingTable(userID);
        ArrayList <String> followings = new ArrayList<>();
        ArrayList <String> followers = new ArrayList<>();
        while (Followings.next()){
            followings.add(Followings.getString(1));
        }
        while (Followers.next()){
            followers.add(Followers.getString(1));
        }
        resultSetLikes.beforeFirst();
        ArrayList <String> postIDs_likedBy_following_followers = new ArrayList<>();
        //the third way of scoring
        while (resultSetLikes.next()){
            for (String follower : followers) {
                if(resultSetLikes.getString("Liker_ID").equals(follower)){
                    postIDs_likedBy_following_followers.add(resultSetLikes.getString(1).substring(0,resultSetLikes.getString(1).length()-1));
                }
            }
            for (String following : followings) {
                if(resultSetLikes.getString("Liker_ID").equals(following)){
                    postIDs_likedBy_following_followers.add(resultSetLikes.getString(1).substring(0,resultSetLikes.getString(1).length()-1));
                }
            }
        }
        counter=0;
        while (resultSet_AD_posts.next()){
            for (String s : postIDs_likedBy_following_followers) {
                if(resultSet_AD_posts.getString("id").equals(s)){
                    Scores.set(counter,Scores.get(counter)+0.01);
                }
            }
            counter++;
        }

        String BlankString ;
        Double BlankInt;
        for (int i = 0; i < Scores.size(); i++) {
            for (int i1 = 0; i1 < Scores.size()-1; i1++) {
                if(Scores.get(i1)<Scores.get(i1+1)){
                    BlankInt = Scores.get(i1);
                    Scores.set(i1,Scores.get(i1+1))  ;
                    Scores.set(i1+1,BlankInt)  ;
                    BlankString = ids_AD_posts.get(i1);
                    ids_AD_posts.set(i1,ids_AD_posts.get(i1+1))  ;
                    ids_AD_posts.set(i1+1,BlankString)  ;
                }
            }
        }
        for (int i = 0; i < ids_AD_posts.size() && i<5; i++) {
            System.out.println(ids_AD_posts.get(i));
        }

    }

    public static void Delete_post(){
        System.out.println("Please enter post id:");
        while (true){
            try{
                String cap= scanner.nextLine().trim();
                if(cap.isEmpty()){
                    System.out.println("Dont enter empty String. dude?!");
                }else {
                    if(Database.delete_Post(cap)>0){
                        System.out.println("Deleted the post successfully.");
                    }else {
                        System.out.println("No post exists with that ID.");
                    }
                    return;
                }
            }catch (Exception e){
                System.out.println("Invalid command!");
            }
        }
    }

    public static void Show_Likes(){
        System.out.println("Is it a post or comment?");
        while (true) {
            String in = scanner.nextLine().trim();
            if (in.equalsIgnoreCase("post")) {
                System.out.println("input the postID:");
                in = scanner.nextLine().trim();
                try {
                    Database.SHOW_LIKES_post(in);
                } catch (SQLException e) {
                    e.printStackTrace();
                }
                return;
            } else if (in.equalsIgnoreCase("comment")) {
                System.out.println("input the commentID:");
                in = scanner.nextLine().trim();
                try {
                    Database.SHOW_LIKES_comment(in);
                } catch (SQLException e) {
                    e.printStackTrace();
                }
                return;
            }
        }
    }

    public static void Show_Comments(){
        System.out.println("Is it a post or comment?");
        while (true) {
            String in = scanner.nextLine().trim();
            if (in.equalsIgnoreCase("post")) {
                System.out.println("input the postID:");
                in = scanner.nextLine().trim();
                try {
                    Database.SHOW_COMMENTS_post(in);
                } catch (SQLException e) {
                    e.printStackTrace();
                }
                return;
            } else if (in.equalsIgnoreCase("comment")) {
                System.out.println("input the commentID:");
                in = scanner.nextLine().trim();
                try {
                    Database.SHOW_COMMENTS_comment(in);
                } catch (SQLException e) {
                    e.printStackTrace();
                }
                return;
            }
        }
    }

    public static void Update_Caption(){
        System.out.println("Please enter new caption:");
        while (true){
            try {
                String cap= scanner.nextLine();
                if(cap.isEmpty()){
                    System.out.println("Dont enter empty String. dude?!");
                }else {
                    String id ;
                    System.out.println("Please enter post id:");
                    id = scanner.nextLine().trim();
                    if(!id.isEmpty()){
                        if(Database.Update_Caption(cap,id)>0){
                            System.out.println("Updated successfully.");
                            return;
                        }else {
                            System.out.println("No post exists with such ID.");
                        }
                    }else {
                        System.out.println("Dont enter empty String. dude?!");
                    }
                }
            }catch (Exception e){
                System.out.println("Invalid command!");
            }
        }
    }

    //getting caption
    public static String post_addText(){
        System.out.println("Please enter the caption:");
        while (true){
            try {
                String caption=scanner.nextLine();
                if(caption.isEmpty()){
                    System.err.println("Caption can't be empty.");
                }else {
                    return caption;
                }
            }catch (Exception e){
                System.err.println("Invalid command.");
            }
        }
    }

    public static String post_postID() throws SQLException {
        int a = Database.get_postNum();
        String postID = post_posterID();
        if(Database.Update_postNum(Database.user_loggedIn(), Database.get_postNum())<=0){
            System.out.println("sth went wrong!");
        }
        return postID+a;
    }

    public static String post_posterID() throws SQLException {
        String user_loggedin = Database.user_loggedIn();
        while (true){
            try {
                if(user_loggedin.isEmpty()){
                    System.out.println("No body is loggedIn!");
                }else {
                    return user_loggedin;
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public static boolean post_ad(){
        System.out.println("Is this an advertising post?(yes/no)");
        while (true){
            try {
                String answer =scanner.nextLine().trim();
                if(answer.equalsIgnoreCase("yes")){
                    if(Database.check_ads(post_posterID())){
                        return true;
                    }else {
                        System.out.println("This is not a business account!");
                    }
                }else if (answer.equalsIgnoreCase("no")){
                    return false;
                }else {
                    System.out.println("invalid command");
                }
            }catch (Exception e){
                System.out.println("invalid command!");
            }
        }
    }

    // haven't checked for errors in path
    public static String post_picture (){
        System.out.println("Please enter picture path:");
        while (true){
            try {
                String path =scanner.nextLine();
                if(!path.isEmpty()){
                    return path;
                }else {
                    System.out.println("It's empty dude!");
                }
            }catch (Exception e){
                System.out.println("Invalid command");
            }
        }
    }

    public static String post_time (){
        return (new Time()).toString();
    }

    public static void Update_Location(String post_id){
        String new_location = post_location();
        while (true){
            try {
                if(Database.Update_location(new_location,post_id)>0){
                    return;
                }else {
                    System.out.println("Couldn't update location.");
                }
            }catch (Exception e){
                System.out.println("invalid command!");
            }
        }
    }

    public static String post_location (){
        System.out.println("Give me your Location:");
        while (true){
            try {
                String Location = scanner.nextLine().trim();
                if(Location.contains("Iran")){
                    System.out.println("hamvatan salam.");
                    System.out.println("Updated.");
                    return Location;
                }else {
                    System.out.println("Updated.");
                    return Location;
                }
            }catch (Exception e){
                System.out.println("invalid command!");
            }
        }
    }

    public static String post_field (){
        System.out.println("Choose the post's field:(insert number)");
        System.out.println("""
                1.sports
                2.entertainment
                3.nature
                4.educational
                5.fashion
                6.political
                7.music
                8.movie
                9.economics
                """);
        while (true){
            try {
                String Location =scanner.next();
                switch (Location){
                    case "1": return "sports";
                    case "2": return "entertainment";
                    case "3": return "nature";
                    case "4": return "educational";
                    case "5": return "fashion";
                    case "6": return "political";
                    case "7": return "music";
                    case "8": return "movie";
                    case "9": return "economics";
                    default: System.out.println("invalid command!"); break;
                }

            }catch (Exception e){
                System.out.println("invalid command!");
            }
        }
    }
}
