package repository;

import entity.Comment;
import entity.Time;
import input.HomePage;
import input.MenuControl;
import jdbc.Database;

import java.sql.SQLException;
import java.util.Scanner;

public class CommentRepository {
    private static final Scanner scanner = new Scanner(System.in);

    public static void create_comment () throws SQLException {
        String post_comment_id = comment_OR_post_ID();
        if(post_comment_id.isEmpty()){
            MenuControl.setMenuNum(HomePage.MENU_NUM);
            MenuControl.inputScanner();
        }
        String commenterID = comment_commenter_ID();
        if(commenterID.isEmpty()){
            MenuControl.setMenuNum(HomePage.MENU_NUM);
            MenuControl.inputScanner();
        }
        int a;
        if(post_comment_id.charAt(post_comment_id.length()-1)=='#'){
            a = Database.get_commentNum_from_comments(post_comment_id.substring(0,post_comment_id.length()-1))+1;
            Database.Update_commentNum_from_comments(post_comment_id.substring(0,post_comment_id.length()-1),a);
        }
        else if(post_comment_id.charAt(post_comment_id.length()-1)=='*'){
            a = Database.get_commentNum_from_posts(post_comment_id.substring(0,post_comment_id.length()-1))+1;
            Database.Update_commentNum_from_posts(post_comment_id.substring(0,post_comment_id.length()-1),a);
        }

        String commentID = comment_comment_ID(post_comment_id,commenterID);

        String time=comment_time();
        String caption = comment_addText();


        if (Database.add_comment(new Comment(post_comment_id,commentID+time,commenterID,caption,time)) > 0){
            System.out.println("commented successful.");
        }else System.err.println("Something went wrong!\n try again.");
    }

    public static void Delete_comment(){
        System.out.println("please enter comment id :");
        while (true){
            try{
                String cap= scanner.nextLine().trim();
                if(cap.isEmpty()){
                    System.out.println("Don't enter empty String. dude?!");
                }else {
                    if(!Database.delete_comment(cap)){
                        int index =0;
                        for (int i = cap.length()-1 ; i >= 0 ; i--) {
                            if(cap.charAt(i)=='*' || cap.charAt(i)=='#' ){
                                index= i;break;
                            }

                        }
                        int a;
                        String post_comment_id = cap.substring(0,index+1);
                        if(post_comment_id.charAt(post_comment_id.length()-1)=='#'){
                            a = Database.get_commentNum_from_comments(post_comment_id.substring(0,post_comment_id.length()-1))-1;
                            Database.Update_commentNum_from_comments(post_comment_id.substring(0,post_comment_id.length()-1),a);
                        }
                        else if(post_comment_id.charAt(post_comment_id.length()-1)=='*'){
                            a = Database.get_commentNum_from_posts(post_comment_id.substring(0,post_comment_id.length()-1))-1;
                            Database.Update_commentNum_from_posts(post_comment_id.substring(0,post_comment_id.length()-1),a);
                        }
                        System.out.println("Deleted the comment successfully.");
                        return;
                    }else {
                        System.out.println("No comment exists with that ID.");
                    }

                }
            }catch (Exception e){
                System.out.println("invalid command!");
            }
        }
    }

    public static void Update_Comment(){
        System.out.println("please enter new caption:");
        while (true){
            try {
                String cap= scanner.nextLine();
                if(cap.isEmpty()){
                    System.out.println("dont enter empty String . dude?!");
                }else {
                    System.out.println("Please enter commentID");
                    String id= scanner.nextLine().trim();
                    if(Database.Update_comment(cap,id)>0){
                        System.out.println("Updated successfully.");
                        return;
                    }else {
                        System.out.println("No comment exists with such ID.");
                    }
                    return;
                }
            }catch (Exception e){
                System.out.println("invalid command!");
            }
        }
    }

    //getting data from user
    public static String comment_commenter_ID() throws SQLException{
        String user_loggedin =Database.user_loggedIn();
        while (true){
            try {
                if(user_loggedin.isEmpty()){
                    System.out.println("No body is loggedIn!");
                }else {
                    return user_loggedin;
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public static String comment_comment_ID(String comment_post_id,String commenterID) throws SQLException {
        String commenter = commenterID ;
        return comment_post_id + commenter ;
    }

    public static String comment_addText(){
        System.out.println("Please enter the caption:");
        while (true){
            try {
                String caption=scanner.nextLine();
                if(caption.isEmpty()){
                    System.err.println("caption can't be empty.");
                }else {
                    return caption;
                }
            }catch (Exception e){
                System.err.println("invalid command.");
            }
        }
    }

    //the one we are leaving comment for
    public static String comment_OR_post_ID (){
        System.out.println("Please enter the id of the post or comment:");
        while (true){
            try {
                String ID= scanner.nextLine().trim();
                if(ID.isEmpty()){
                    System.err.println("id can't be empty.");
                }else {
                    System.out.println("is it a commentID or a postID?(comment/post)");
                    String caption= scanner.nextLine().trim();
                    if(caption.equalsIgnoreCase("comment")){
                        if(Database.check_existence_comment(ID)){
                            return ID+"#";
                        }else {
                            System.out.println("There is no comment with such ID!");
                            return "";
                        }
                    }else if (caption.equalsIgnoreCase("post")){
                        if(Database.check_existence_post(ID)){
                            return ID+"*";
                        }else {
                            System.out.println("There is no post with such ID!");
                            return "";
                        }
                    }
                }
            }catch (Exception e){
                System.err.println("invalid command.");
            }
        }
    }

    public static String comment_time (){
        return (new Time()).toString();
    }
}
